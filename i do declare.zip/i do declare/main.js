var numberOne = 1.11;
var numberTwo = -2;
var numberThree = 3.00;
var numberFour = -4.10;

var stringOne = "hello";
var stringTwo = "hi";
var stringThree = "hello again";

var booleanOne = true;
var booleanTwo = false;

undefinedVariable = "umm";

console.log("The First Number:", numberOne);
console.log("The Second Number:", numberTwo);
console.log("The Third Number:", numberThree);
console.log("The Fourth Number:", numberFour);
console.log("The First String:", stringOne);
console.log("The Second String:", stringTwo);
console.log("The Third String:", stringThree);
console.log("The First Boolean:", booleanOne);
console.log("The Second Boolean:", booleanTwo);
console.log("The undefinedVariable:", undefinedVariable);