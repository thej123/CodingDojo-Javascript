var daysUntilMyBirthday = 60;

while (daysUntilMyBirthday > 0) {
    while (daysUntilMyBirthday > 30) {
        console.log(daysUntilMyBirthday + " days until my birthday. Such a long time... :(");
        daysUntilMyBirthday--;
    }
    console.log(daysUntilMyBirthday + " DAYS UNTIL MY BIRTHDAY!!!");
    daysUntilMyBirthday--;
}
console.log("........................");
console.log("HAPPY BIRTHDAY");
console.log("........................");